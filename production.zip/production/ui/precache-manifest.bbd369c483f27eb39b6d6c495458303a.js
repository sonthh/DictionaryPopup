self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7e832245c3214de28406eff70d7c6556",
    "url": "./index.html"
  },
  {
    "revision": "d14db9f31e08b77b5f0f",
    "url": "./static/css/main.de38691f.chunk.css"
  },
  {
    "revision": "814d3b0041d73da27913",
    "url": "./static/js/2.340c9533.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.340c9533.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d14db9f31e08b77b5f0f",
    "url": "./static/js/main.762aeaa7.chunk.js"
  },
  {
    "revision": "dbab036f87ca1350243a",
    "url": "./static/js/runtime-main.851de3a6.js"
  },
  {
    "revision": "09c8b4069400db4251e7e27db6c9d31c",
    "url": "./static/media/about_icon.09c8b406.png"
  },
  {
    "revision": "5c4cf36414bf94869533b6f1fe59c8bd",
    "url": "./static/media/home_icon.5c4cf364.png"
  },
  {
    "revision": "9f822d65ff6ba4a3c017207aba84caa2",
    "url": "./static/media/settings_icon.9f822d65.png"
  }
]);